## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----airway-example-----------------------------------------------------------
example_pkgs <- c("airway", "DESeq2", "MultiAssayExperiment", "S4Vectors")
if (all(vapply(example_pkgs, requireNamespace, logical(1), quietly = TRUE))) {
  data("airway", package = "airway")
  counts <- SummarizedExperiment::assay(airway, "counts")
  metadata <- as.data.frame(SummarizedExperiment::colData(airway))
  metadata <- metadata[colnames(counts), , drop = FALSE]

  mae <- MultiAssayExperiment::MultiAssayExperiment(
    experiments = list(rnaseq = SummarizedExperiment::SummarizedExperiment(
      assays = list(counts = counts)
    )),
    colData = S4Vectors::DataFrame(metadata)
  )

  res <- DAssemble::DAssemble(
    features = mae,
    assay_name = "rnaseq",
    core_method = "DESeq2",
    enhancers = c("WLX", "LR"),
    expVar = "dex",
    p_adj = "BH",
    enhancer_norm = "tmm",
    return_components = TRUE,
    return_subensembles = TRUE
  )

  head(res$res)
  names(res$components)
}

## ----microbiome-example-------------------------------------------------------
example_pkgs <- c("phyloseq", "MultiAssayExperiment", "S4Vectors")
if (all(vapply(example_pkgs, requireNamespace, logical(1), quietly = TRUE))) {
  data("GlobalPatterns", package = "phyloseq")
  gp <- GlobalPatterns

  otu <- as(phyloseq::otu_table(gp), "matrix")
  metadata <- as.data.frame(phyloseq::sample_data(gp))

  keep <- metadata$SampleType %in% c("Feces", "Soil")
  features <- as.data.frame(t(otu[, keep]))
  metadata <- metadata[keep, , drop = FALSE]
  metadata$group <- droplevels(factor(metadata$SampleType))
  stopifnot(nlevels(metadata$group) == 2L)

  mae <- MultiAssayExperiment::MultiAssayExperiment(
    experiments = list(microbiome = SummarizedExperiment::SummarizedExperiment(
      assays = list(counts = t(as.matrix(features)))
    )),
    colData = S4Vectors::DataFrame(metadata)
  )

  res <- DAssemble::DAssemble(
    features = mae,
    assay_name = "microbiome",
    core_method = NULL,
    enhancers = c("WLX", "LR", "KS"),
    expVar = "group",
    enhancer_norm = "clr",
    return_components = TRUE,
    return_subensembles = TRUE
  )

  head(res$res)
  names(res$components)
  head(res$ensembles)
}

## ----session-info-------------------------------------------------------------
sessionInfo()

